﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace pr6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string inputFilePath = "input.txt";
        private string outputFilePath = "output.txt";

        public MainWindow()
        {
            InitializeComponent();
        }

       
        private string ExtractLowercaseRussianLetters(string input)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in input)
            {
                if (c >= 'а' && c <= 'я')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LstDataFile2.Items.Clear();
               
                foreach (string item in LstDataFile1.Items)
                {
                    string processedString = ExtractLowercaseRussianLetters(item);
                    LstDataFile2.Items.Add(processedString);
                }

                using (StreamWriter swriter = new StreamWriter(outputFilePath, false, Encoding.UTF8))
                {
                    foreach (string item in LstDataFile2.Items)
                    {
                        swriter.WriteLine(item);
                    }
                }

                MessageBox.Show($"Данные сохранены в файл {outputFilePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during file creation: {ex.Message}", "Error");
            }
        }

        private void BtnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "Текстовые файлы (*.txt)|*.txt|Скриты (*.sql)|*.sql|Документы (*.docx)|*.docx";

                if (ofd.ShowDialog() == true)
                {
                    inputFilePath = ofd.FileName; 

                    LstDataFile1.Items.Clear(); 

                    using (StreamReader sreader = new StreamReader(inputFilePath, Encoding.UTF8))
                    {
                        while (!sreader.EndOfStream)
                        {
                            string line = sreader.ReadLine();
                            LstDataFile1.Items.Add(line);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening file: {ex.Message}", "Error");
            }
        }

        private void BtnAddItem_Click(object sender, RoutedEventArgs e)
        {
            string line = TxtAdd.Text;

            if (string.IsNullOrWhiteSpace(line))
            {
                MessageBox.Show("Введите текст для добавления.");
                return;
            }

            if (LstDataFile1.SelectedItem != null)
            {
                int selectedIndex = LstDataFile1.SelectedIndex;
                LstDataFile1.Items[selectedIndex] = line;
                MessageBox.Show("Строка успешно обновлена.");
            }
            else
            {
                LstDataFile1.Items.Add(line);
            }

            TxtAdd.Clear();
        }

        private void BtnRemoveItem_Click(object sender, RoutedEventArgs e)
        {
            if (LstDataFile1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выделите текст для удаления списка.", "Предупреждение");
                return;
            }

            List<int> indicesToRemove = new List<int>();
            foreach (var item in LstDataFile1.SelectedItems)
            {
                indicesToRemove.Add(LstDataFile1.Items.IndexOf(item));
            }

            indicesToRemove.Sort((a, b) => b.CompareTo(a)); 
            foreach (int index in indicesToRemove)
            {
                LstDataFile1.Items.RemoveAt(index);
            }
        }

        private void BtnEditItem_Click(object sender, RoutedEventArgs e)
        {
            if (LstDataFile1.SelectedItem == null)
            {
                MessageBox.Show("Выберите элемент для редактирования.");
                return;
            }

            string selectedItem = LstDataFile1.SelectedItem.ToString();
            TxtAdd.Text = selectedItem;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            LstDataFile1.Items.Clear();
            LstDataFile2.Items.Clear();
        }
    }
}