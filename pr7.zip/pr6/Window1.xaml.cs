﻿using System;
using System.Windows;

namespace pr6
{
    public partial class Window1 : Window
    {
        private double[] FarrayNumber = new double[18];  
        private double[] ParrayNumber = new double[18];  
        private Random rand = new Random();

        public Window1()
        {
            InitializeComponent();
        }

        private void Farray()
        {
            for (int i = 0; i < 18; i++)
            {
                double num = Math.Round(rand.NextDouble() * 100 - 100, 3);
                FarrayNumber[i] = num;
                LstDataFile1.Items.Add($"F[{i}] = {num:F3}");
            }
        }

        private void CalculateP()
        {
            LstDataFile2.Items.Clear();
            for (int i = 0; i < FarrayNumber.Length; i++)
            {
                double f = FarrayNumber[i];
                double p = 0.13 * Math.Pow(f, 3) - 2.5 * f + 8;
                ParrayNumber[i] = p;
                if (p < 0)
                {
                    LstDataFile2.Items.Add($"P[{i}] = {p:F3}");
                }
            }
        }

        private void BtnExze_Click(object sender, RoutedEventArgs e)
        {
            if (FarrayNumber[0] == 0)  
            {
                MessageBox.Show("Сначала создайте массив F с помощью кнопки 'Создать'.");
                return;
            }

            LstDataFile2.Items.Clear();
            CalculateP();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            LstDataFile1.Items.Clear();
            LstDataFile2.Items.Clear();
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            LstDataFile1.Items.Clear();
            Farray(); 
        }
    }
}
